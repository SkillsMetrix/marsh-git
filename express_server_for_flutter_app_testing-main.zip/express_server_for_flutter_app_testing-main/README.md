# express_server_for_flutter_app_testing

How to run:

npm install

node server
